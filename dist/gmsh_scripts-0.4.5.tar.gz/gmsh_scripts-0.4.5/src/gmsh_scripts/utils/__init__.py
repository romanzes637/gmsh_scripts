from obj2gmsh import main as obj2gmsh

__all__ = ['obj2gmsh']
